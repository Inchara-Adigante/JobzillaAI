"""Edges package."""
